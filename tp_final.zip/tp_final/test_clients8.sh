#!/bin/bash
# Lancer 8 clients simultanés avec des messages différents

# Listes ny hafatra samihafa
messages=(
    "Manao ahoana"
    "Salama tompoko"
    "Akory lahaly"
    "Inona ny vaovao"
    "Tafita ve ny hafatra"
    "Andrana faha-enina"
    "Efa ho vita ny TP"
    "Veloma ary"
)

for i in $(seq 1 8); do
    # Alaina ny hafatra avy ao amin'ny array (ny index dia i-1 satria manomboka amin'ny 0 ny array)
    msg="${messages[$((i-1))]}"
    
    # Alefa ny mpanjifa miaraka amin'ny sleep 10 mba hanomezana fotoana anao hanao ps aux
    (echo "Client $i : $msg"; sleep 40) | nc -q 1 127.0.0.1 9999 &
done

wait
echo 'Tous les clients ont terminé'