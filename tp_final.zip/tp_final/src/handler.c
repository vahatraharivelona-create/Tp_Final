#include "server.h"

void handle_client(int connfd, int conn_num) {
    char buffer[BUFFER_SIZE];
    int n;

    
    while ((n = read(connfd, buffer, BUFFER_SIZE - 1)) > 0) {
        buffer[n] = '\0'; // Ampiana end-of-string
        
        printf("[Client #%d] Nandefa: %s", conn_num, buffer);



        char response[BUFFER_SIZE + 50];
        snprintf(response, sizeof(response), "[Connexion #%d] Echo : %s", conn_num, buffer);
        
     
        if (write(connfd, response, strlen(response)) < 0) {
            perror("Write failed");
            break;
        }
        memset(buffer, 0, BUFFER_SIZE);
    }
}