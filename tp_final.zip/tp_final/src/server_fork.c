#include "server.h"
#include <sys/wait.h>
#include <signal.h>
#include <sys/mman.h> // Ho an'ny mmap
#include <asm-generic/signal-defs.h>



static int *shared_conn_count;

void sigchld_handler(int s) {
    (void)s;

    while(waitpid(-1, NULL, WNOHANG) > 0) {
        if (*shared_conn_count > 0) {
            (*shared_conn_count)--;
        }
    }
}

int main(void) {
    int listenfd, connfd;
    struct sockaddr_in srv;
    int opt = 1;
    pid_t pid;

    // --- Q7: IMPLEMENTATION MEMOIRE PARTAGEE POSIX ---
    shared_conn_count = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, 
                             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    *shared_conn_count = 0; 

    // 1. Socket
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    srv.sin_family = AF_INET;
    srv.sin_addr.s_addr = INADDR_ANY;
    srv.sin_port = htons(PORT);

    if (bind(listenfd, (struct sockaddr *)&srv, sizeof(srv)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }
    listen(listenfd, BACKLOG);

    // 2. Q6: Signal handler 
    struct sigaction sa;
    sa.sa_handler = sigchld_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP; 
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        perror("sigaction");
        exit(1);
    }

    printf("[SERVER FORK] server actif Port %d...\n", PORT);

    while (1) {
        connfd = accept(listenfd, NULL, NULL);
        if (connfd < 0) {
            if (errno == EINTR) continue; 
            perror("Accept failed");
            continue;
        }

        (*shared_conn_count)++;
        printf("\n[PÈRE] NOUVEAU CLIENT RECU. Connexions actives : %d\n", *shared_conn_count);

        // 3. Q5: Fork
        pid = fork();

        if (pid < 0) {
            perror("Fork failed");
            (*shared_conn_count)--;
            close(connfd);
        } 
        else if (pid == 0) { 
            /* --- FILS --- */
            close(listenfd); 
            
         
            printf("[Fils %d] prepare de nouveaux client (Total active: %d)\n", getpid(), *shared_conn_count);
            
            handle_client(connfd, *shared_conn_count); 
            
            close(connfd);
            exit(0); 
        } 
        else {
            /* --- PÈRE --- */
            close(connfd); 
            
        }
    }

    // Famafana ny shared memory rehefa hiala (tsy tratra eto ny code fa ilaina ho fantatra)
    munmap(shared_conn_count, sizeof(int));
    return 0;
}