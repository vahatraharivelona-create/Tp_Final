#include "server.h"
#include <pthread.h>
#include <sys/stat.h>
#include <syslog.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <signal.h>

#define MAX_THREADS 16
#define PID_FILE "/tmp/myserverd.pid"

int connexions_actives = 0;
pthread_mutex_t mutex_connexions = PTHREAD_MUTEX_INITIALIZER;

void* handle_client_daemon(void* arg) {
    int connfd = *((int*)arg);
    free(arg); 
    pthread_detach(pthread_self());

    char buffer[BUFFER_SIZE];
    ssize_t n;

    while ((n = read(connfd, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';
        syslog(LOG_INFO, "[THREAD %lu] Data voaray: %s", (unsigned long)pthread_self(), buffer);
        write(connfd, buffer, n); // Echo
    }

    pthread_mutex_lock(&mutex_connexions);
    connexions_actives--;
    syslog(LOG_INFO, "[THREAD %lu] Client disconnected. Total actives: %d", (unsigned long)pthread_self(), connexions_actives);
    pthread_mutex_unlock(&mutex_connexions);

    close(connfd);
    return NULL;
}

// 5.2 Squelette de la fonction daemonize() - Q17, Q18, Q19
void daemonize() {
    pid_t pid;

    /* 1er fork (Q17) */
    if ((pid = fork()) < 0) { syslog(LOG_ERR, "fork 1 epoka: %m"); exit(1); }
    if (pid > 0) exit(0); 
    
    if (setsid() < 0) { syslog(LOG_ERR, "setsid epoka: %m"); exit(1); } /* Nouvelle session */

    /* 2ème fork (Q18) */
    if ((pid = fork()) < 0) { syslog(LOG_ERR, "fork 2 epoka: %m"); exit(1); }
    if (pid > 0) exit(0);

    /* Q19: chdir, umask, redirection fds */
    if (chdir("/") < 0) { syslog(LOG_ERR, "chdir epoka: %m"); exit(1); }
    umask(0);

    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    int fd0 = open("/dev/null", O_RDONLY);
    int fd1 = open("/dev/null", O_WRONLY);
    int fd2 = open("/dev/null", O_RDWR);   
    
    (void)fd0; (void)fd1; (void)fd2;
}


int check_if_running(const char *pidfile) {
    int fd = open(pidfile, O_RDONLY);
    if (fd >= 0) {
        char buf[16];
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            buf[n] = '\0';
            pid_t old_pid = atoi(buf);
            if (kill(old_pid, 0) == 0) {
                return -1; 
            }
        }
    }
    return 0;
}


void write_pid_file(const char *pidfile, pid_t pid) {
    int fd = open(pidfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd >= 0) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d\n", pid);
        write(fd, buf, strlen(buf));
        close(fd);
    }
}

int main() {
    openlog("myserverd", LOG_PID | LOG_CONS, LOG_DAEMON);

    
    if (check_if_running(PID_FILE) < 0) {
        syslog(LOG_ERR, "Erreur: Misy instance an'ny server efa mandeha sahady!");
        fprintf(stderr, "Erreur: Misy instance an'ny server efa mandeha sahady! Jereo ny syslog.\n");
        closelog();
        exit(1); 
    }

    
    
    daemonize();


    write_pid_file(PID_FILE, getpid());
    syslog(LOG_INFO, "Server daemonised soa aman-tsara miaraka amin'ny PID %d", getpid());

    int listenfd, connfd;
    struct sockaddr_in srv;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    srv.sin_family = AF_INET;
    srv.sin_addr.s_addr = INADDR_ANY;
    srv.sin_port = htons(PORT);

    if (bind(listenfd, (struct sockaddr *)&srv, sizeof(srv)) < 0) {
        syslog(LOG_ERR, "Bind epoka: %m");
        exit(1);
    }
    listen(listenfd, BACKLOG);

    while (1) {
        connfd = accept(listenfd, NULL, NULL);
        if (connfd < 0) continue;

        pthread_mutex_lock(&mutex_connexions);
        if (connexions_actives >= MAX_THREADS) {
            syslog(LOG_WARNING, "Refus de connexion: Pool saturé (%d/%d)", connexions_actives, MAX_THREADS);
            char *msg = "Erreur: Serveur saturé.\n";
            if (write(connfd, msg, strlen(msg)) < 0) { syslog(LOG_ERR, "Erreur write: %m"); }
            close(connfd);
            pthread_mutex_unlock(&mutex_connexions);
            continue;
        }

        int *fd_copy = malloc(sizeof(int));
        *fd_copy = connfd;
        connexions_actives++;
        syslog(LOG_INFO, "Client vaovao. Total actives: %d", connexions_actives);
        pthread_mutex_unlock(&mutex_connexions);

        pthread_t tid;
        pthread_create(&tid, NULL, handle_client_daemon, fd_copy);
    }

    unlink(PID_FILE);
    closelog();
    return 0;
}