#include "server.h"

int main(void) {
    int listenfd, connfd;
    struct sockaddr_in srv;
    int opt = 1;
    int conn_count = 0;

    // 1. Création socket TCP
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // 2. Option SO_REUSEADDR 
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // 3. Configuration adresse sy Port
    srv.sin_family = AF_INET;
    srv.sin_addr.s_addr = INADDR_ANY;
    srv.sin_port = htons(PORT);

    // 4. Bind
    if (bind(listenfd, (struct sockaddr *)&srv, sizeof(srv)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // 5. Listen
    if (listen(listenfd, BACKLOG) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("[SERVER] SERVER ITERATIF  port %d...\n", PORT);

    // 6. Boucle infinite 
    while (1) {
        connfd = accept(listenfd, NULL, NULL);
        if (connfd < 0) {
            perror("Accept failed");
            continue;
        }

        conn_count++;
        printf("[SERVER] NOUVEAU CLIENT (Connexion #%d)\n", conn_count);

        
        handle_client(connfd, conn_count);
        
        close(connfd); 
    }

    return 0;
}