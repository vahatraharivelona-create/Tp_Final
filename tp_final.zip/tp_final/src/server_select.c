#include "server.h"
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define MAX_CLIENTS FD_SETSIZE

int main() {
    int listenfd, connfd, maxfd, nready;
    int clients[MAX_CLIENTS];
    fd_set rset, allset;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in srv;
    struct timeval timeout;
    int total_surveilles = 0;

   
    for (int i = 0; i < MAX_CLIENTS; i++) clients[i] = -1;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0) { perror("socket error"); exit(1); }
    
    int opt = 1;
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    srv.sin_family = AF_INET;
    srv.sin_addr.s_addr = INADDR_ANY;
    srv.sin_port = htons(PORT);

    if (bind(listenfd, (struct sockaddr *)&srv, sizeof(srv)) < 0) { perror("bind error"); exit(1); }
    if (listen(listenfd, BACKLOG) < 0) { perror("listen error"); exit(1); }

    
    FD_ZERO(&allset);
    FD_SET(listenfd, &allset);
    maxfd = listenfd;

    printf("[SELECT] Server mihaino amin'ny port %d (Multiplexage)...\n", PORT);

    while (1) {
        rset = allset; 
        timeout.tv_sec = 5; // Timeout 5 secondes (Q15)
        timeout.tv_usec = 0;

       
        total_surveilles = 1; 
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i] >= 0) total_surveilles++;
        }
        printf("[INFO] Descripteurs arahi-maso izao: %d\n", total_surveilles);

        nready = select(maxfd + 1, &rset, NULL, NULL, &timeout);

        if (nready < 0) { perror("select error"); break; }
        if (nready == 0) {
          
            printf("[LOG] Timeout 5s: Miandry foana... (Surveillés: %d)\n", total_surveilles);
            continue;
        }

     
        if (FD_ISSET(listenfd, &rset)) {
            connfd = accept(listenfd, NULL, NULL);
            if (connfd >= 0) {
                int i;
                for (i = 0; i < MAX_CLIENTS; i++) {
                    if (clients[i] < 0) {
                        clients[i] = connfd; 
                        break;
                    }
                }
                if (i == MAX_CLIENTS) {
                    printf("[WARN] Be loatra ny mpanjifa, feno ny tableau!\n");
                    close(connfd);
                } else {
                    FD_SET(connfd, &allset); 
                    if (connfd > maxfd) maxfd = connfd; // Havaozina ny maxfd
                    printf("[NEW] Client vaovao tafiditra: FD %d\n", connfd);
                }
            }
            if (--nready <= 0) continue;
        }


    
        for (int i = 0; i < MAX_CLIENTS; i++) {
            int sockfd = clients[i];
            if (sockfd < 0) continue;

            if (FD_ISSET(sockfd, &rset)) {
                memset(buffer, 0, sizeof(buffer));
                int n = read(sockfd, buffer, BUFFER_SIZE - 1);
                
                if (n == 0) { 
                    
                    printf("[OFF] Client amin'ny FD %d niala.\n", sockfd);
                    close(sockfd);
                    FD_CLR(sockfd, &allset);
                    clients[i] = -1;         
                } else if (n > 0) {
                 
                    printf("[DATA] Hafatra azo avy amin'ny FD %d: %s", sockfd, buffer);
                    
                    
                    write(sockfd, buffer, n); 
                }
                
                if (--nready <= 0) break; 
            }
        }
    }
    
    close(listenfd);
    return 0;
}