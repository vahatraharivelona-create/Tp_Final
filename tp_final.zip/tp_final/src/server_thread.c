#include "server.h"
#include <pthread.h>

#define MAX_THREADS 2

// Q11: Compteur global sy Mutex ho an'ny fiarovana (Thread-safety)
int connexions_actives = 0;
pthread_mutex_t mutex_connexions = PTHREAD_MUTEX_INITIALIZER;

// Fonction ivelany avy ao amin'ny handler_thread.c
extern void* handle_client_thread(void* arg);

int main(void) {
    int listenfd, connfd;
    struct sockaddr_in srv;
    int opt = 1;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    srv.sin_family = AF_INET;
    srv.sin_addr.s_addr = INADDR_ANY;
    srv.sin_port = htons(PORT);

    if (bind(listenfd, (struct sockaddr *)&srv, sizeof(srv)) < 0) {
        perror("Bind failed");
        exit(1);
    }
    listen(listenfd, BACKLOG);

    printf("[SERVER THREAD] ECOUTE Port %d (Pool Max: %d)...\n", PORT, MAX_THREADS);

    while (1) {
        connfd = accept(listenfd, NULL, NULL);
        if (connfd < 0) continue;

        // Q11 & Q12: Jerena ny isan'ny mpanjifa (miaraka amin'ny Mutex)
        pthread_mutex_lock(&mutex_connexions);
        if (connexions_actives >= MAX_THREADS) {
            printf("[REFUS] Pool saturé (%d/%d)\n", connexions_actives, MAX_THREADS);
            char *msg = "Erreur: Serveur saturé. TENTER AVEO .\n";
            write(connfd, msg, strlen(msg));
            close(connfd);
            pthread_mutex_unlock(&mutex_connexions);
            continue;
        }
        
        connexions_actives++;
        printf("[MAIN] Client vaovao. Total actives: %d\n", connexions_actives);
        pthread_mutex_unlock(&mutex_connexions);

        // Q9: Passage sécurisé amin'ny alalan'ny malloc (copie du descripteur)
        int *fd_ptr = malloc(sizeof(int));
        *fd_ptr = connfd;

        pthread_t tid;
        if (pthread_create(&tid, NULL, handle_client_thread, fd_ptr) != 0) {
            perror("pthread_create failed");
            free(fd_ptr);
            close(connfd);
        }
    }
    return 0;
}