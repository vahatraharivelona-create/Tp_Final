#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define BUFFER_SIZE 1024

int main() {
  
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);

    char buffer[BUFFER_SIZE];
    ssize_t n;

    
    while ((n = read(STDIN_FILENO, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';
        
        
        if (write(STDOUT_FILENO, buffer, n) < 0) {
            exit(1);
        }
    }

    return 0;
}