#include "server.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


extern int connexions_actives;
extern pthread_mutex_t mutex_connexions;

void* handle_client_thread(void* arg) {
    
    int connfd = *((int*)arg);
    free(arg); 

   
    pthread_detach(pthread_self());

    char buffer[BUFFER_SIZE];
    ssize_t n;

    // Loop handraisana hafatra (Echo)
    while ((n = read(connfd, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';
        printf("[THREAD %lu] Naharay: %s", (unsigned long)pthread_self(), buffer);
        
      
        write(connfd, buffer, n);
    }

   
    
    pthread_mutex_lock(&mutex_connexions);
    connexions_actives--; 
    printf("[THREAD %lu] Client deco. Total actives: %d\n", (unsigned long)pthread_self(), connexions_actives);
    pthread_mutex_unlock(&mutex_connexions);

    close(connfd);
    return NULL; 
}